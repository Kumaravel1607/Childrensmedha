// import 'package:cmedha/Api/Api_services/Remote_services.dart';
// import 'package:cmedha/Models/Competitive_model.dart';
// import 'package:cmedha/screens/Constant/color.dart';
// import 'package:cmedha/screens/widget.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:readmore/readmore.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';

// class ExamScreen extends StatefulWidget {
//   final int type;

//   const ExamScreen({Key? key, required this.type}) : super(key: key);
//   @override
//   State<ExamScreen> createState() => _ExamScreenState();
// }

// List<CompetitiveExam> exam = [];

// class Exam {
//   final String des;
//   final String name;
//   final String image;

//   final bool isFavorite;

//   Exam({
//     required this.name,
//     required this.des,
//     this.isFavorite = false,
//     required this.image,
//   });

//   Exam copyWith({String? des, bool? isFavorite}) => Exam(
//       des: des ?? this.des,
//       isFavorite: isFavorite ?? this.isFavorite,
//       name: '',
//       image: '');
// }

// final List<Exam> ExamData = [
//   Exam(
//       name: 'SAINK',
//       des:
//           'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       image: 'assets/images/exam.png'),
//   Exam(
//       name: 'RMIS',
//       des:
//           '	Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       image: 'assets/images/exam.png'),
//   Exam(
//       name: 'NAVODAYA',
//       des:
//           'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       image: 'assets/images/exam.png'),
//   Exam(
//       name: 'RMIS',
//       des:
//           'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       image: 'assets/images/exam.png'),
// ];

// class _ExamScreenState extends State<ExamScreen> {
//   List<CompetitiveExam> exams = [];

//   late Future<void> _fetchExams;

//   @override
//   void initState() {
//     super.initState();
//     _fetchExams = _examlist();
//   }

//   Future<List<CompetitiveExam>> CompetitiveExamData() async {
//     SharedPreferences session = await SharedPreferences.getInstance();

//     try {
//       var url = 'https://dreams.hashref.org/api/competitive-exam-type';
//       var urlparse = Uri.parse(url);

//       final response = await http.post(
//         Uri.parse('https://dreams.hashref.org/api/competitive-exam-type'),
//         body: jsonEncode({'type': widget.type.toString()}),
//         headers: {'Content-Type': 'application/json'},
//       );
//       print(urlparse);

//       if (response.statusCode == 200) {
//         final responseBody = json.decode(response.body);
//         exams = competitiveExamResponse(jsonEncode(responseBody['result']));
//         return exams;
//       } else {
//         print('Failed to fetch data. Status code: ${response.statusCode}');
//         throw Exception('Problem in fetching data');
//       }
//     } catch (error) {
//       print('Error: $error');
//       throw Exception('Problem in fetching data');
//     }
//   }

//   static List<CompetitiveExam> competitiveExamResponse(String responseBody) {
//     final parsed = json.decode(responseBody).cast<Map<String, dynamic>>();
//     return parsed
//         .map<CompetitiveExam>((json) => CompetitiveExam.fromJson(json))
//         .toList();
//   }

//   _examlist() async {
//     SharedPreferences session = await SharedPreferences.getInstance();
//     print("--------");
//     var id = session.getInt('id');
//     print("--------");
//     RemoteService.CompetitiveExamData().then((result) {
//       setState(() {
//         exam = result;
//       });
//     });
//   }

//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.blue,
//         shadowColor: Colors.black,
//       ),
//       body: FutureBuilder(
//         future: _fetchExams,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(child: CircularProgressIndicator());
//           } else if (snapshot.hasError) {
//             return Center(child: Text('Error: ${snapshot.error}'));
//           } else {
//             // Corrected the ListView.builder usage
//             return ListView.builder(
//               physics: AlwaysScrollableScrollPhysics(),
//               itemCount: exams.length,
//               shrinkWrap: true,
//               scrollDirection: Axis.vertical,
//               itemBuilder: (BuildContext context, int index) {
//                 final examType =
//                     exams[index].examType; // Corrected variable name

//                 if ((examType == 1) || (examType == 2)) {
//                   // Check whether the current examType matches the desired tab type

//                   return GestureDetector(
//                     onTap: () {
//                       // Handle the onTap event
//                       // You can navigate to the specific details screen or perform other actions
//                     },
//                     child: Padding(
//                       padding: const EdgeInsets.symmetric(horizontal: 10),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           text20(exams[index].examName, black),
//                           const SizedBox(height: 10),
//                           ClipRRect(
//                             borderRadius: BorderRadius.circular(10),
//                             child: Container(
//                               width: double.infinity,
//                               height: 160,
//                               decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(5),
//                                 image: DecorationImage(
//                                   image: NetworkImage(exams[index].image),
//                                   fit: BoxFit.fill,
//                                 ),
//                               ),
//                             ),
//                           ),
//                           const SizedBox(height: 5),
//                           Row(
//                             children: [
//                               text20('Published on : ', dash),
//                               text20(
//                                 DateFormat.yMd().format(exams[index].date),
//                                 dash,
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 10),
//                           ReadMoreText(
//                             exams[index].shortDescription,
//                             trimLines: 5,
//                             style: TextStyle(color: Colors.black),
//                             colorClickableText: Colors.blue,
//                             trimMode: TrimMode.Line,
//                             trimCollapsedText: 'read more',
//                             trimExpandedText: 'read less',
//                             moreStyle: TextStyle(
//                                 fontSize: 14, fontWeight: FontWeight.bold),
//                           ),
//                           const SizedBox(height: 10),
//                           Divider(
//                             thickness: 5,
//                             color: Colors.grey,
//                             height: 10,
//                           ),
//                         ],
//                       ),
//                     ),
//                   );
//                 } else {
//                   // If the examType doesn't match, return an empty container
//                   return Container();
//                 }
//               },
//             );
//           }
//         },
//       ),
//     );
//   }
// }

// Column(
//   crossAxisAlignment: CrossAxisAlignment.start,
//   children: [
//     const SizedBox(
//       height: 5,
//     ),
//     text20('SAINK', black),
//     const SizedBox(
//       height: 10,
//     ),
//     const ReadMoreText(
//       'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       trimLines: 7,
//       style: TextStyle(color: Colors.black),
//       colorClickableText: Blue,
//       trimMode: TrimMode.Line,
//       trimCollapsedText: 'read more',
//       trimExpandedText: 'read less',
//       moreStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
//     ),
//     const SizedBox(
//       height: 10,
//     ),
//     text20('RMIS', black),
//     const SizedBox(
//       height: 10,
//     ),
//     const ReadMoreText(
//       'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       trimLines: 7,
//       style: TextStyle(color: Colors.black),
//       colorClickableText: Blue,
//       trimMode: TrimMode.Line,
//       trimCollapsedText: 'read more',
//       trimExpandedText: 'read less',
//       moreStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
//     ),
//     const SizedBox(
//       height: 10,
//     ),
//     text20('NAVODAYA', black),
//     const SizedBox(
//       height: 10,
//     ),
//     const ReadMoreText(
//       'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.',
//       trimLines: 7,
//       style: TextStyle(color: Colors.black),
//       colorClickableText: Blue,
//       trimMode: TrimMode.Line,
//       trimCollapsedText: 'read more',
//       trimExpandedText: 'read less',
//       moreStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
//     ),
//   ],
// ),
//     ),
//   );
// }

//   Widget buildExamTab({required bool type}) {
//     return
// }

import 'package:cmedha/Api/Api_services/Remote_services.dart';
import 'package:cmedha/Models/Competitive_model.dart';
import 'package:cmedha/screens/Constant/color.dart';
import 'package:cmedha/screens/widget.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:readmore/readmore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ExamScreen extends StatefulWidget {
  final int type;

  const ExamScreen({Key? key, required this.type}) : super(key: key);

  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  List<CompetitiveExam> exams = [];
  late Future<void> _fetchExams;

  @override
  void initState() {
    super.initState();
    _fetchExams = _examList();
  }

  Future<void> _examList() async {
    SharedPreferences session = await SharedPreferences.getInstance();

    try {
      var url = 'https://dreams.hashref.org/api/competitive-exam-type';
      var urlparse = Uri.parse(url);

      final response = await http.post(
        Uri.parse('https://dreams.hashref.org/api/competitive-exam-type'),
        body: jsonEncode({'type': widget.type.toString()}),
        headers: {'Content-Type': 'application/json'},
      );
      print(urlparse);

      if (response.statusCode == 200) {
        final responseBody = json.decode(response.body);
        exams = competitiveExamResponse(jsonEncode(responseBody['result']));
        setState(() {}); // Update the state to trigger a rebuild
      } else {
        print('Failed to fetch data. Status code: ${response.statusCode}');
        throw Exception('Problem in fetching data');
      }
    } catch (error) {
      print('Error: $error');
      throw Exception('Problem in fetching data');
    }
  }

  static List<CompetitiveExam> competitiveExamResponse(String responseBody) {
    final parsed = json.decode(responseBody).cast<Map<String, dynamic>>();
    return parsed
        .map<CompetitiveExam>((json) => CompetitiveExam.fromJson(json))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.chevron_left,
            size: 25,
            color: white,
          ),
        ),
        titleSpacing: 10,
        leadingWidth: 30,
        shadowColor: black,
        backgroundColor: Blue,
        title: text20('Exams', white),
        elevation: 3,
      ),
      body: FutureBuilder(
        future: _fetchExams,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            return ListView.builder(
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: exams.length,
              shrinkWrap: true,
              scrollDirection: Axis.vertical,
              itemBuilder: (BuildContext context, int index) {
                final examType = exams[index].examType;

                if ((examType == 1) || (examType == 2)) {
                  return GestureDetector(
                    onTap: () {
                      // Handle the onTap event
                      // You can navigate to the specific details screen or perform other actions
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text20(exams[index].examName, black),
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              width: double.infinity,
                              height: 160,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                image: DecorationImage(
                                  image: NetworkImage(exams[index].image),
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 5),
                          Row(
                            children: [
                              text20('Published on : ', dash),
                              text20(
                                DateFormat.yMd().format(exams[index].date),
                                dash,
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          ReadMoreText(
                            exams[index].shortDescription,
                            trimLines: 5,
                            style: TextStyle(color: Colors.black),
                            colorClickableText: Colors.blue,
                            trimMode: TrimMode.Line,
                            trimCollapsedText: 'read more',
                            trimExpandedText: 'read less',
                            moreStyle: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 10),
                          Divider(
                            thickness: 5,
                            color: Colors.grey,
                            height: 10,
                          ),
                        ],
                      ),
                    ),
                  );
                } else {
                  return Container();
                }
              },
            );
          }
        },
      ),
    );
  }
}
